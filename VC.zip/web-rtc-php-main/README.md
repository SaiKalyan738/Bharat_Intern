# WebRTC Uygulaması
Bu proje, WebRTC (Web Gerçek Zamanlı İletişim) kullanarak video ve ses iletişimi sağlayan basit bir web uygulamasını içerir. Bu uygulama, tarayıcınızın kamera ve mikrofonunu kullanarak video konferans yapmanızı sağlar.

## Kurulum
Bu uygulamayı kullanmak için aşağıdaki adımları izleyin:

* Bu projeyi bilgisayarınıza kopyalayın veya indirin.

* index.php dosyasını bir web sunucusuna yerleştirin.

* Web sunucusunun çalıştığı adresi tarayıcınızda açın.

* Uygulama, kamera ve mikrofon erişimi isteyecektir. İzinleri verin.

* Uygulama, tarayıcınızdaki video ve ses akışını görüntüleyecektir.

 ## Kullanım
 ### Uygulamayı kullanırken aşağıdaki kontrolleri kullanabilirsiniz:

* Kamera Açma/Kapatma: Kamerayı açmak veya kapatmak için "Kamera" düğmesine tıklayın. Kamera kapalıyken, kendi video akışınız diğer katılımcılara gönderilmez.

* Mikrofon Açma/Kapatma: Mikrofonu açmak veya kapatmak için "Mikrofon" düğmesine tıklayın. Mikrofon kapalıyken, sesiniz diğer katılımcılara gönderilmez.

* Ekran Paylaşma: Ekranınızı paylaşmak için "Ekran Paylaşımı" düğmesine tıklayın. Bu özellik, ekranınızın video akışını diğer katılımcılara gönderir.

* Ayrılma: Video konferanstan ayrılmak için "Ayrıl" düğmesine tıklayın. Bu, video ve ses akışınızı durduracak ve bağlantıyı sonlandıracaktır.

# Özelleştirme
Bu proje, Bootstrap ve Font Awesome gibi üçüncü taraf kütüphaneleri kullanır. Özelleştirme yapmak isterseniz, index.php dosyasında yer alan CSS ve JavaScript bağlantılarını değiştirebilir veya yeni stiller ve işlevler ekleyebilirsiniz.
## Javascript Düzenlemesi Gereken Yerler
send signal fonksiyonunda example.com yazan yere domainizi ve daha sonra iki noktadan sonra kullanacağınız port numarasını yazın </br></br>
function sendSignal(type, data) {</br>
    var xhr = new XMLHttpRequest();</br>
    xhr.open('POST', 'https://example.com:8080/signal.php', true);</br>
    xhr.setRequestHeader('Content-Type', 'application/json');</br>
    xhr.onreadystatechange = function () {</br>
        if (xhr.readyState === 4 && xhr.status === 200) {</br>
            console.log('Sinyal gönderildi: ' + type);</br>
        }</br>
    };</br>
    xhr.send(JSON.stringify({ type: type, data: data, id: roomId }));</br>
}</br>
</br>
Bu Düzenlemeleri Yapınca Javascript Kodunuz Düzgünce Çalışcaktır peer bağlantısı sağlancaktır
## Port Ayarları
Bu uygulama, WebRTC bağlantıları kurmak ve sinyal verilerini iletmek için belirli bir portu kullanır. Varsayılan olarak, signal.php dosyası, 8080 numaralı port üzerinden sinyal verilerini alır ve gönderir.

### Eğer farklı bir port kullanmak isterseniz, aşağıdaki adımları izleyin:

* index.php dosyasını açın.

* sendSignal fonksiyonunun içinde, xhr.open satırını bulun.
İlgili satırda, URL'nin sonuna :8080 kısmını bulun ve istediğiniz port numarasıyla değiştirin.
Örneğin, farklı bir port kullanmak için :8888 gibi bir değer girin.

* Dosyayı kaydedin ve değişiklikleri uygulayın.

Not: Port numarasını değiştirirken, ilgili portun kullanılabilir olduğundan emin olun ve gerekli ağ yapılandırmalarını yapın.
