<?php

// Gelen sinyal verilerini tutmak için bir dizi oluşturun
$signals = [];

// POST isteği alındığında çalışacak işlev
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Gelen verileri alın
    $data = json_decode(file_get_contents('php://input'), true);

    // Gelen sinyal türüne göre işlem yapın
    switch ($data['type']) {
        case 'offer':
        case 'answer':
        case 'candidate':
            // Sinyali diziye ekleyin
            $signals[$data['id']][] = $data;
            break;
        case 'close':
            // Sinyali diziye ekleyin ve diğer tarafa kapatma sinyali gönderin
            $signals[$data['id']][] = $data;
            sendSignal($data['target'], $data);
            break;
    }
}

// GET isteği alındığında çalışacak işlev
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Gelen verileri alın
    $id = $_GET['id'];
    $target = $_GET['target'];
    // İlgili sinyalleri alın
    $targetSignals = $signals[$id] ?? [];

    // Sinyalleri diğer tarafa gönderin
    foreach ($targetSignals as $signal) {
        sendSignal($target . ':8080', $signal);
    }

    // Sinyalleri temizle
    unset($signals[$id]);
}

// Sinyali hedefe gönderen işlev
function sendSignal($target, $signal)
{
    $ch = curl_init($target);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($signal));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}
?>
