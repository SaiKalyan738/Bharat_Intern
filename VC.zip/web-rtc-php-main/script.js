var localStream, localVideo;
var localPeerConnection;
var screenStream, screenVideo;
var isScreenSharing = false;
var roomId;

var urlParams = new URLSearchParams(window.location.search);
var roomId = urlParams.get('room_id');


navigator.mediaDevices.getUserMedia({ video: true, audio: true })
    .then(function (stream) {
        localStream = stream;
        localVideo = document.createElement('video');
        localVideo.srcObject = stream;
        localVideo.autoplay = true;
        localVideo.muted = true;
        localVideo.classList.add('video-grid-item');
        document.querySelector('.video-grid').appendChild(localVideo);
    })
    .catch(function (error) {
        console.log("Kamera ve mikrofon erişimi reddedildi: " + error);
    });

function start() {
    var configuration = {
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
    };

    localPeerConnection = new RTCPeerConnection(configuration);

    localStream.getTracks().forEach(function (track) {
        localPeerConnection.addTrack(track, localStream);
    });

    localPeerConnection.onicecandidate = function (event) {
        if (event.candidate) {
            sendSignal('candidate', event.candidate);
        }
    };

    localPeerConnection.createOffer()
        .then(function (offer) {
            return localPeerConnection.setLocalDescription(offer);
        })
        .then(function () {
            sendSignal('offer', localPeerConnection.localDescription);
        })
        .catch(function (error) {
            console.log("Bağlantı hatası: " + error);
        });
}

function startScreenSharing() {
    navigator.mediaDevices.getDisplayMedia({ video: true, audio: true })
        .then(function (stream) {
            screenStream = stream;
            screenVideo = document.createElement('video');
            screenVideo.srcObject = stream;
            screenVideo.autoplay = true;
            screenVideo.classList.add('video-grid-item');
            document.querySelector('.video-grid').appendChild(screenVideo);
            isScreenSharing = true;

            if (localPeerConnection) {
                screenStream.getTracks().forEach(function (track) {
                    localPeerConnection.addTrack(track, screenStream);
                });

                localPeerConnection.createOffer()
                    .then(function (offer) {
                        return localPeerConnection.setLocalDescription(offer);
                    })
                    .then(function () {
                        sendSignal('offer', localPeerConnection.localDescription);
                    })
                    .catch(function (error) {
                        console.log("Bağlantı hatası: " + error);
                    });
            } else {
                console.log("localPeerConnection nesnesi henüz oluşturulmadı.");
            }
        })
        .catch(function (error) {
            console.log("Ekran paylaşımı başarısız: " + error);
            isScreenSharing = false;
        });
}


function stopScreenSharing() {
    if (screenStream) {
        screenStream.getTracks().forEach(function (track) {
            track.stop();
        });
        screenVideo.remove();
        isScreenSharing = false;

        localPeerConnection.createOffer()
            .then(function (offer) {
                return localPeerConnection.setLocalDescription(offer);
            })
            .then(function () {
                sendSignal('offer', localPeerConnection.localDescription);
            })
            .catch(function (error) {
                console.log("Bağlantı hatası: " + error);
            });
    }
}


function sendSignal(type, data) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://example.com:8080/signal.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            console.log('Sinyal gönderildi: ' + type);
        }
    };
    xhr.send(JSON.stringify({ type: type, data: data, id: roomId }));
}

document.getElementById('toggleCameraButton').addEventListener('click', function () {
    var videoTracks = localStream.getVideoTracks();
    var icon = this.querySelector('i');

    if (videoTracks[0].enabled) {
        // Kamera kapatılıyor
        videoTracks[0].enabled = false;
        icon.classList.remove('fa-video');
        icon.classList.add('fa-video-slash');
        // Kamera ışığı da kapatılıyor
        localStream.getVideoTracks().forEach(function (track) {
            track.stop();
        });
        console.log("Kamera  Kapatıldı");
    } else {
        // Kamera açılıyor
        videoTracks[0].enabled = true;
        icon.classList.remove('fa-video-slash');
        icon.classList.add('fa-video');
        // Kamera ışığı da açılıyor
        navigator.mediaDevices.getUserMedia({ video: true, audio: false })
            .then(function (stream) {
                localStream.getVideoTracks().forEach(function (track) {
                    track.stop();
                });
                localStream.removeTrack(localStream.getVideoTracks()[0]);
                localStream.addTrack(stream.getVideoTracks()[0]);
            })
            .catch(function (error) {
                console.log("Kamera erişimi reddedildi: " + error);
            });
            console.log("Kamera  Açıldı");
    }
});

document.getElementById('toggleMicrophoneButton').addEventListener('click', function () {
    var audioTracks = localStream.getAudioTracks();
    var icon = this.querySelector('i');

    if (audioTracks[0].enabled) {
        // Mikrofon kapatılıyor
        audioTracks.forEach(function (track) {
            track.enabled = false;
        });
        icon.classList.remove('fa-microphone');
        icon.classList.add('fa-microphone-slash');
          console.log("Mikrofon  Kapatıldı");
    } else {
        // Mikrofon açılıyor
        audioTracks.forEach(function (track) {
            track.enabled = true;
        });
        icon.classList.remove('fa-microphone-slash');
        icon.classList.add('fa-microphone');
        console.log("Mikrofon  Açıldı");
    }
});


document.getElementById('toggleScreenSharingButton').addEventListener('click', function () {
    if (isScreenSharing) {
        stopScreenSharing();
    } else {
        startScreenSharing();
    }
});

document.getElementById('leaveButton').addEventListener('click', function () {
    sendSignal('close', null);
    localStream.getTracks().forEach(function (track) {
        track.stop();
    });
    localVideo.remove();
});



document.querySelector('.settings-icon').addEventListener('click', function () {
    // Settings icon click event handler
});

start();
