<!DOCTYPE html>
<html>
<head>
    <title>WebRTC APP</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="main-content">
        <div class="video-grid" id="videoGridContainer"></div>
    </div>
    <div class="control-panel">
        <button class="control-button btn btn-primary" id="toggleCog"><i class="fas fa-cog"></i></button>
        <button class="control-button btn btn-primary" id="toggleCameraButton"><i class="fas fa-video"></i></button>
        <button class="control-button btn btn-primary" id="toggleMicrophoneButton"><i class="fas fa-microphone"></i></button>
        <button class="control-button btn btn-primary" id="toggleScreenSharingButton"><i class="fa fa-desktop"></i></button>
        <button class="btn btn-danger" id="leaveButton"><i class="fas fa-sign-out-alt"></i> Leave</button>
      
    </div>

    <script src="script.js"></script>

</body>
</html>
